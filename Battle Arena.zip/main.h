#ifndef Z6_LIBRARY_H
#define Z6_LIBRARY_H

void hello(void);

#endif //Z6_LIBRARY_H